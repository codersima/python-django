from django.db import models
from django.urls import reverse
# No models in this app